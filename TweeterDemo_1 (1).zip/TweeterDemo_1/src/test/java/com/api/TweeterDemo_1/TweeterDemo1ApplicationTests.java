package com.api.TweeterDemo_1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TweeterDemo1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
